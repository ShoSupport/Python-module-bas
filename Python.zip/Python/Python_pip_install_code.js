_call_function(Python_pip_install,{ "Имя модуля": (<%= xzrlweuu %>) })!
<%= variable %> = _result_function()
