_call_function(Python_Loading,{  })!
<%= variable %> = _result_function()
