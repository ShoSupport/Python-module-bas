_call_function(Python_run_code,{ "Код": (<%= rciitrda %>),"Рабочая папка": (<%= vgcmtjei %>) })!
<%= variable %> = _result_function()
