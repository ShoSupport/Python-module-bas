_call_function(Python_Cheak,{  })!
<%= variable %> = _result_function()
